﻿namespace ViewControlApp
{
    internal class ListViewSubitemCollection
    {
    }
}